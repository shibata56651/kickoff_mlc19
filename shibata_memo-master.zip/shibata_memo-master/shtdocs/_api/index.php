<?php

require_once __DIR__ . '/../../libs/DB.php';

session_start();

$settings = [
    'host' => '192.168.0.11',
    'port' => '3380',
    'data' => 'kickoff_test',
    'user' => 'root',
    'pass' => '',
    'table' => 'depart',
];

/**
 * Router処理
 */

$uri = $_SERVER['REQUEST_URI'];

switch (true)
{
    /**
     * ログイン
     */
    case preg_match('/^\/_api\/login\/$/', $uri):
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' )
        {
            $_SESSION['login'] = $_POST['login'];
            header('Location: /');
        }
        break;
    /**
     * 一覧表示
     */
    case preg_match('/^\/_api\/result\/$/', $uri):
        $db = new DB($settings);
        echo json_encode($db->showAll());
        break;

    /**
     * ランキング表示
     */
    case preg_match('/^\/_api\/ranking\/$/', $uri):
        $db = new DB($settings);
        echo json_encode($db->ranking());
        break;

    /**
     * 人数登録
     */
    case preg_match('/^\/_api\/$/', $uri):
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' )
        {
            $db = new DB($settings);
            $db->update($_POST);
            header('Location: /');
        }
        break;

    /**
     * 採点機能
     */
    case preg_match('/^\/_api\/score\/$/', $uri):
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' )
        {
            $json = file_get_contents('php://input');
            $json = json_decode($json, true);
            $db = new DB($settings);
            echo $db->score($json);
            // header('Location: /ranking.html');
        }
        break;

    case preg_match('/^\/_api\/refresh\/$/', $uri):

        $db = new DB($settings);
        $db->reflesh();
        header('Location: /');
        break;
}