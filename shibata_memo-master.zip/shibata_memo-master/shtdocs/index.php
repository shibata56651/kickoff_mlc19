<? session_start(); ?>
<!DOCTYPE html>
<html lang='ja'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv='X-UA-Compatible' content='ie=edge'>
    <title>人数入力画面</title>
</head>
<body>
    <a href='/'>人数入力画面</a>
    <a href='result.html'>回答結果発表画面</a>
    <a href='ranking.html'>ランキング発表画面</a>
    <a href='score.html'>結果表示＆正解発表画面</a>
    <a href='login.html'>ログイン画面</a>
    <a href='./_api/refresh/'>リセット</a>※ポイント、解答がリセットされます
    <h1>人数フォーム</h1>
    <form action='./_api/' method='POST'>
        <input type='hidden' name='id' value='<?=$_SESSION['login']?>'>
        <p>回答を入力してください。</p>
        <select name='answer'><? for ($i=1; $i <= 25 ; $i++): ?>
            <option value='<?=$i?>'><?=$i?></option>
        <? endfor ?></select>
        <input type='submit' value='回答する'>
    </form>
</body>
</html>