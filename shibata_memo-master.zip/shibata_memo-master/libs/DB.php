<?php

class DB
{
    protected $settings;
    protected $pdo;

    public function __construct($settings)
    {
        $this->settings = $settings;
        $this->pdo = DB::connectDB();
    }

    /**
     * DB接続
     */
    public function connectDB()
    {
        try
        {
            return new PDO('mysql:host='.$this->settings['host'].';port='.$this->settings['port'].';dbname='.$this->settings['data'],
                            $this->settings['user'], $this->settings['pass']);
        }
        catch (PDOException $e)
        {
            exit($e->getMessage());
        }
    }

    /**
     * 全件表示
     */
    public function showAll ()
    {
        $sql = 'SELECT * FROM '.$this->settings['table'];
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * ランキング表示
     */
    public function ranking ()
    {
        $sql = 'SELECT * FROM '.$this->settings['table'].' ORDER BY `point` DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 人数登録
     */
    public function update($postData)
    {
        $sql = 'UPDATE '.$this->settings['table'].' SET answer = :answer WHERE id = :id';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($postData);
        return ['status' => 'success'];
    }

    /**
     * 採点機能
     */
    public function score($postData)
    {
        $sql = 'UPDATE '.$this->settings['table'].' SET diff = ABS(answer - :answer)';
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':answer', $postData['answer']);
        $stmt->execute();

        $sql = 'SELECT diff FROM '.$this->settings['table'].' ORDER BY diff ASC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();

        $first = $stmt->fetchColumn();
        $second = $stmt->fetchColumn();
        $third = $stmt->fetchColumn();

        $sql = 'UPDATE '.$this->settings['table'].' SET point = (point + 3) WHERE diff = :diff';
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':diff', $first);
        $stmt->execute();

        if ( $first != $second )
        {
            $sql = 'UPDATE '.$this->settings['table'].' SET point = (point + 2) WHERE diff = :diff';
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':diff', $second);
            $stmt->execute();
        }

        if ( $second != $third )
        {
            $sql = 'UPDATE '.$this->settings['table'].' SET point = (point + 1) WHERE diff = :diff';
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':diff', $third);
            $stmt->execute();
        }

        $sql = 'SELECT * FROM '.$this->settings['table'].' WHERE diff = :diff OR diff = :diff1 OR diff = :diff2';
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':diff', $first);
        $stmt->bindParam(':diff1', $second);
        $stmt->bindParam(':diff2', $third);
        $stmt->execute();

        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public function reflesh()
    {
        $sql = 'UPDATE '.$this->settings['table'].' SET point = 0, answer= 0, diff = 0';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
    }

}