# shibata_memo

キックオフページを作成するプロジェクトです。

## LINK

[キックオフ](https://kickoff.onakahara-jin.code.mitsue.co.jp/)
