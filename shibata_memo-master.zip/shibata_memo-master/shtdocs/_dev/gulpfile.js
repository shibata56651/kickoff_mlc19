(function () {
    'use strict';

    const gulp = require('gulp');
    const sass = require('gulp-sass');
    const plumber = require('gulp-plumber');
    const rename = require('gulp-rename');

    const path = {
      img: '../common/images/',
      js: '../common/js/',
      sass: './scss/',
      css: '../common/css/'
    }

    gulp.task('sass', function () {
      return gulp.src('./scss/**/*.scss')
      .pipe(plumber())
      .pipe(sass({
        outputStyle: 'expanded'
      }))
      .pipe(rename('style.css'))
      .pipe(gulp.dest('../common/css/'))
    });

    gulp.task('default', function () {
      return gulp.watch('../_dev/scss/**/*.scss', gulp.task('sass'));
    });
}());
